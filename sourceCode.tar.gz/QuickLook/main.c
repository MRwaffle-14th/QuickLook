#include <stdio.h>
#include <unistd.h>

int main()
{
    // initializing variable for ram
    long total = 0; // total memory
    long used = 0; // currently used
    long available = 0; // currently available
    double usedPerc = 0; // used but in percentage

    // line-buffer for file
    char line[256];

    // creating and opening maininfo
    FILE *fp = fopen("/proc/meminfo", "r");
    if (!fp) // checking if it exists and printing an error if it doesnt
    {
        perror("fopen");
        return 1;
    }

    // reading line-by-line
    while (fgets(line, sizeof(line), fp))
    {
        // scanning each line and assign to vars if encountering correct info
        if (total == 0 && sscanf(line, "MemTotal: %ld", &total) == 1) continue;
        if (available == 0 && sscanf(line, "MemAvailable: %ld", &available) == 1) continue;

        // getting the fuck out if we are done here!
        if (total && available) break;
    }

    // closing the file
    fclose(fp);

    // more init vars
    used = total - available;
    usedPerc = (double)used / total * 100;

    // printing information
    printf("[RAM]\n");

    printf("Total memory: %.1f MB\n", total/1024.0);
    printf("Available memory: %.1f MB\n", available/1024.0);
    printf("Used memory: %.1f%%\n", usedPerc);
    printf("\n");

    // initializing variables for cpu
    unsigned long long prev_user = 0;
    unsigned long long prev_nice = 0;
    unsigned long long prev_system = 0;
    unsigned long long prev_idle = 0;
    unsigned long long curr_user = 0;
    unsigned long long curr_nice = 0;
    unsigned long long curr_system = 0;
    unsigned long long curr_idle = 0;
    unsigned long long prev_total = 0;
    unsigned long long curr_total = 0;
    unsigned long long delta_total = 0;
    unsigned long long delta_idle = 0;
    unsigned long long prev_iowait = 0;
    unsigned long long curr_iowait = 0;
    double cpu_usage = 0;

    // creating and opening stat
    FILE *fp2 = fopen("/proc/stat", "r");
    if (!fp2) // checking if it exists and printing an error if it doesnt
    {
        perror("fopen");
        return 1;
    }

    // read and match variables
    if (fgets(line, sizeof(line), fp2))
    {
        // sscanf to extract user nice system idle and iowait
        sscanf(line, "cpu  %llu %llu %llu %llu %llu", &prev_user, &prev_nice, &prev_system, &prev_idle, &prev_iowait);
    }

    // cloaing the file
    fclose(fp2);
    // waiting for 10 ms
    usleep(10000);

    // opening file for the second time
    fp2 = fopen("/proc/stat", "r");
    if (!fp2)
    {
        perror("fopen");
        return 1;
    }

    if (fgets(line, sizeof(line), fp2))
    {
        // sscanf to extract (current) user nice system idle and iowait
        sscanf(line, "cpu  %llu %llu %llu %llu %llu", &curr_user, &curr_nice, &curr_system, &curr_idle, &curr_iowait);
    }

    // calculating deltas, totals, and usage
    prev_total = prev_user + prev_nice + prev_system + prev_idle + prev_iowait;
    curr_total = curr_user + curr_nice + curr_system + curr_idle + curr_iowait;

    delta_total = curr_total - prev_total;
    delta_idle  = (curr_idle + curr_iowait) - (prev_idle + prev_iowait);

    cpu_usage = (double)(delta_total - delta_idle) / delta_total * 100;

    // printing information
    printf("[CPU]\n");
    printf("cpu usage: %.1f%%\n", cpu_usage);
    printf("\n");

    // initializing gpu variables
    FILE *fp3;
    char gpu_line[64];
    int gpu_usage = 0;

    fp3 = popen("nvidia-smi --query-gpu=utilization.gpu --format=csv,noheader,nounits", "r");
    fgets(gpu_line, sizeof(gpu_line), fp3);
    sscanf(gpu_line, "%d", &gpu_usage);
    pclose(fp3);

    // printing information
    printf("[GPU]\n");
    printf("gpu usage: %.1f%%\n", (double)gpu_usage);

    return 0;
}
